angular.module('lsi').constant('config', {
    API_URL: 'http://lsiweb.azurewebsites.net/'
});