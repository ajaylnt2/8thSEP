angular.module('lsi').constant('config', {
    API_URL: 'http://10.20.201.168:8080/'
});